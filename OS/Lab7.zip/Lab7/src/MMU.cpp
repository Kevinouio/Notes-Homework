#include <cse4733/MMU.hpp>

#include <iostream>
#include <stdexcept>

namespace cse4733 {

MMU::MMU(int numPages, unsigned int base_address, unsigned int offset) :
    pageTable(),
    tlbHits{0},
    tlbMisses{0},
    m_base_address(base_address)
{}

auto MMU::addEntry(unsigned int virtualAddress) -> unsigned int
{
    // TODO: Implement this function
    // 1. Create the physical address equal to the virtual address plus the base address
    // 2. Add the translation to the TLB
    // 3. Calculate where to insert the physical address into the page table
    // 4. Add the physical address to the page table
}

unsigned int MMU::translateAddress(unsigned int virtualAddress) {

    // TODO:
    //
    // This function should translate a given virtual address to a physical address:
    //
    // 1. It should check that the address is within the 0 to offset range bounds.
    // Throw an exception of std::out_of_range if it is not.
    //
    // 2. It should check if the translation is in the TLB (a TLB hit).
    //    a. If it is, it should return the physical address from the TLB
    //       and increment the count of TLB hits.

    // 3. If it is NOT in the TLB (a TLB miss), it should:
    //    a. It should look up the physical address in the page table with
    //       the 'virtual address' variable.
    //    b. If the physical address IS NOT in the page table, it should
    //       1) Set the physical address to the virtual address plus the base address
    //       2) Add the translation to the TLB
    //       3) Store the physical address in the page table
    //    c. Otherwise, the physical address IS in the page table, it should
    //       1) Create an entry in the TLB table
    //    d. Increment the count of TLB misses.
    //
    // 4. Return the physical address.
    return 0;
}

auto MMU::getHitRatio() const -> double
{
    // TODO:
    //   - Calculate HIT ratio
    return 0.0;
}

auto MMU::getMissRatio() const -> double
{
    // TODO:
    //   - Calculate MISS ratio
    return 0.0;
}

}  // namespace cse4733
