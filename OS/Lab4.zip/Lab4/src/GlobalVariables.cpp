// Purpose: Source file for GlobalVariables.hpp. Declares global variables.

#include "cse4733/GlobalVariables.hpp"

std::shared_ptr<cse4733::ProcessManager> g_processManager = nullptr;